-- Pokedex Intelligence Platform - DDL
-- Run via scripts/run_ddl.py

CREATE DATABASE IF NOT EXISTS POKEDEX;
USE DATABASE POKEDEX;

CREATE SCHEMA IF NOT EXISTS RAW;
CREATE SCHEMA IF NOT EXISTS STAGING;
CREATE SCHEMA IF NOT EXISTS MARTS;
CREATE SCHEMA IF NOT EXISTS ML;

CREATE WAREHOUSE IF NOT EXISTS POKE_WH
  WITH WAREHOUSE_SIZE='XSMALL' AUTO_SUSPEND=60 AUTO_RESUME=TRUE INITIALLY_SUSPENDED=TRUE;

-- Internal stage for images
CREATE STAGE IF NOT EXISTS POKEDEX.RAW.POKE_IMAGES_STAGE
  ENCRYPTION = (TYPE = 'SNOWFLAKE_SSE');

-- Raw stats (matches pokemon (1).csv)
CREATE OR REPLACE TABLE POKEDEX.RAW.POKEMON_STATS (
  abilities STRING,
  against_bug FLOAT, against_dark FLOAT, against_dragon FLOAT, against_electric FLOAT,
  against_fairy FLOAT, against_fight FLOAT, against_fire FLOAT, against_flying FLOAT,
  against_ghost FLOAT, against_grass FLOAT, against_ground FLOAT, against_ice FLOAT,
  against_normal FLOAT, against_poison FLOAT, against_psychic FLOAT, against_rock FLOAT,
  against_steel FLOAT, against_water FLOAT,
  attack INT, base_egg_steps INT, base_happiness INT, base_total INT,
  capture_rate STRING, classfication STRING, defense INT, experience_growth INT,
  height_m FLOAT, hp INT, japanese_name STRING, name STRING,
  percentage_male FLOAT, pokedex_number INT, sp_attack INT, sp_defense INT, speed INT,
  type1 STRING, type2 STRING, weight_kg FLOAT, generation INT, is_legendary INT
);

-- Raw evolution chain (matches pokemon.csv)
CREATE OR REPLACE TABLE POKEDEX.RAW.POKEMON_EVOLUTION (
  name STRING,
  type1 STRING,
  type2 STRING,
  evolution STRING
);

-- Image metadata (actual bytes live on the stage)
CREATE OR REPLACE TABLE POKEDEX.RAW.POKEMON_IMAGES (
  pokedex_number INT,
  name STRING,
  file_name STRING,
  stage_path STRING
);

-- Marts
CREATE OR REPLACE TABLE POKEDEX.MARTS.DIM_POKEMON (
  pokedex_number INT,
  name STRING,
  type1 STRING,
  type2 STRING,
  generation INT,
  is_legendary BOOLEAN,
  hp INT, attack INT, defense INT, sp_attack INT, sp_defense INT, speed INT,
  base_total INT, height_m FLOAT, weight_kg FLOAT,
  classfication STRING, abilities STRING
);

CREATE OR REPLACE TABLE POKEDEX.MARTS.DIM_TYPES (
  type_name STRING
);

CREATE OR REPLACE TABLE POKEDEX.MARTS.FACT_TYPE_EFFECTIVENESS (
  pokedex_number INT,
  name STRING,
  attacking_type STRING,
  multiplier FLOAT
);

CREATE OR REPLACE TABLE POKEDEX.MARTS.FACT_BATTLES (
  attacker_id INT,
  defender_id INT,
  attacker_name STRING,
  defender_name STRING,
  attacker_score FLOAT,
  defender_score FLOAT,
  winner_id INT
);

CREATE OR REPLACE TABLE POKEDEX.MARTS.AGG_WIN_RATES (
  pokedex_number INT,
  name STRING,
  wins INT,
  total INT,
  win_rate FLOAT
);

-- ML
CREATE OR REPLACE TABLE POKEDEX.ML.POKEMON_EMBEDDINGS (
  pokedex_number INT,
  name STRING,
  embedding VECTOR(FLOAT, 512)
);
