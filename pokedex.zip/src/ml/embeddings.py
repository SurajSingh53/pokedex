"""Generate image embeddings with ResNet50 and upload to ML.POKEMON_EMBEDDINGS."""
from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd
import torch
from PIL import Image
from torchvision import models, transforms

from src.config import IMAGES_DIR, get_session

EMB_DIM = 512  # ResNet18 avgpool output; switch to 2048 for ResNet50


def _build_model() -> torch.nn.Module:
    # ResNet18 for speed; gives a 512-dim embedding from penultimate layer.
    weights = models.ResNet18_Weights.DEFAULT
    base = models.resnet18(weights=weights)
    base.fc = torch.nn.Identity()
    base.eval()
    return base


def _preprocess() -> transforms.Compose:
    return transforms.Compose([
        transforms.Lambda(lambda img: img.convert("RGBA")),
        transforms.Lambda(_flatten_alpha),
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
    ])


def _flatten_alpha(img: Image.Image) -> Image.Image:
    """Paste RGBA onto white to avoid transparent backgrounds confusing the CNN."""
    bg = Image.new("RGB", img.size, (255, 255, 255))
    bg.paste(img, mask=img.split()[-1])
    return bg


@torch.no_grad()
def compute_embeddings() -> pd.DataFrame:
    session = get_session()
    meta = session.table("POKEDEX.RAW.POKEMON_IMAGES").to_pandas()

    model = _build_model()
    tfm = _preprocess()

    rows = []
    for _, r in meta.iterrows():
        path = Path(IMAGES_DIR) / r["FILE_NAME"]
        if not path.exists():
            continue
        img = Image.open(path)
        tensor = tfm(img).unsqueeze(0)
        emb = model(tensor).squeeze(0).numpy().astype(np.float32)
        rows.append({
            "POKEDEX_NUMBER": int(r["POKEDEX_NUMBER"]),
            "NAME": r["NAME"],
            "EMBEDDING": emb.tolist(),
        })

    df = pd.DataFrame(rows)
    print(f"Computed {len(df)} embeddings (dim={len(df.iloc[0]['EMBEDDING'])})")
    return df


def upload(df: pd.DataFrame) -> None:
    session = get_session()
    # Write as ARRAY first, then cast to VECTOR in a follow-up insert.
    session.sql("TRUNCATE TABLE POKEDEX.ML.POKEMON_EMBEDDINGS").collect()

    staging = df.copy()
    staging["EMBEDDING"] = staging["EMBEDDING"].apply(lambda v: list(map(float, v)))
    session.write_pandas(
        staging,
        table_name="POKEMON_EMBEDDINGS_STG",
        database="POKEDEX",
        schema="ML",
        overwrite=True,
        auto_create_table=True,
    )

    dim = len(df.iloc[0]["EMBEDDING"])
    session.sql(
        f"""
        INSERT INTO POKEDEX.ML.POKEMON_EMBEDDINGS (POKEDEX_NUMBER, NAME, EMBEDDING)
        SELECT POKEDEX_NUMBER, NAME, EMBEDDING::VECTOR(FLOAT, {dim})
        FROM POKEDEX.ML.POKEMON_EMBEDDINGS_STG
        """
    ).collect()

    session.sql("DROP TABLE IF EXISTS POKEDEX.ML.POKEMON_EMBEDDINGS_STG").collect()
    print("Uploaded to ML.POKEMON_EMBEDDINGS")


def find_similar(pokedex_number: int, top_k: int = 10) -> pd.DataFrame:
    session = get_session()
    return session.sql(
        f"""
        WITH target AS (
          SELECT EMBEDDING FROM POKEDEX.ML.POKEMON_EMBEDDINGS
          WHERE POKEDEX_NUMBER = {pokedex_number}
        )
        SELECT e.POKEDEX_NUMBER, e.NAME,
               VECTOR_COSINE_SIMILARITY(e.EMBEDDING, t.EMBEDDING) AS SIMILARITY
        FROM POKEDEX.ML.POKEMON_EMBEDDINGS e, target t
        WHERE e.POKEDEX_NUMBER != {pokedex_number}
        ORDER BY SIMILARITY DESC
        LIMIT {top_k}
        """
    ).to_pandas()


if __name__ == "__main__":
    df = compute_embeddings()
    upload(df)
