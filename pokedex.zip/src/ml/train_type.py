"""Train a multiclass classifier to predict TYPE1 from stats."""
from __future__ import annotations

from snowflake.ml.modeling.ensemble import RandomForestClassifier
from snowflake.ml.modeling.metrics import accuracy_score
from snowflake.ml.registry import Registry

from src.config import get_session

FEATURES = ["HP", "ATTACK", "DEFENSE", "SP_ATTACK", "SP_DEFENSE", "SPEED",
            "BASE_TOTAL", "HEIGHT_M", "WEIGHT_KG"]
LABEL = "TYPE1"
MODEL_NAME = "POKEMON_TYPE_CLF"


def train() -> None:
    session = get_session()
    df = session.table("POKEDEX.MARTS.DIM_POKEMON").select(*FEATURES, LABEL).dropna()

    train_df, test_df = df.random_split([0.8, 0.2], seed=42)

    clf = RandomForestClassifier(
        input_cols=FEATURES,
        label_cols=[LABEL],
        output_cols=["PREDICTION"],
        n_estimators=300,
        random_state=42,
    )
    clf.fit(train_df)
    preds = clf.predict(test_df)
    acc = accuracy_score(df=preds, y_true_col_names=LABEL, y_pred_col_names="PREDICTION")
    print(f"Type classifier - accuracy={acc:.3f}")

    reg = Registry(session=session, database_name="POKEDEX", schema_name="ML")
    reg.log_model(
        clf,
        model_name=MODEL_NAME,
        version_name="V1",
        comment="Predicts primary type from stats",
        metrics={"accuracy": acc},
    )
    print(f"Registered model {MODEL_NAME}/V1")


if __name__ == "__main__":
    train()
