"""Natural-language Q&A over MARTS.DIM_POKEMON using Snowflake Cortex."""
from __future__ import annotations

import pandas as pd

from src.config import get_session

SCHEMA_DESCRIPTION = """
Table: POKEDEX.MARTS.DIM_POKEMON
Columns:
  POKEDEX_NUMBER INT, NAME STRING,
  TYPE1 STRING, TYPE2 STRING (lowercase; e.g. 'fire', 'water', '' for none),
  GENERATION INT (1-7),
  IS_LEGENDARY BOOLEAN,
  HP INT, ATTACK INT, DEFENSE INT,
  SP_ATTACK INT, SP_DEFENSE INT, SPEED INT,
  BASE_TOTAL INT, HEIGHT_M FLOAT, WEIGHT_KG FLOAT,
  CLASSFICATION STRING, ABILITIES STRING

Table: POKEDEX.MARTS.AGG_WIN_RATES (POKEDEX_NUMBER, NAME, WINS, TOTAL, WIN_RATE)
""".strip()

PROMPT_TEMPLATE = """You are a SQL expert. Translate the user question into a valid
Snowflake SQL query against the following schema. Return ONLY the SQL, no prose.

{schema}

User question: {question}
"""


def nl_to_sql(question: str, model: str = "mistral-large2") -> str:
    session = get_session()
    prompt = PROMPT_TEMPLATE.format(schema=SCHEMA_DESCRIPTION, question=question)
    row = session.sql(
        "SELECT SNOWFLAKE.CORTEX.COMPLETE(?, ?) AS SQL_TEXT",
        params=[model, prompt],
    ).collect()
    sql = row[0]["SQL_TEXT"].strip()
    # Strip markdown fences if present
    if sql.startswith("```"):
        sql = sql.strip("`")
        if sql.lower().startswith("sql"):
            sql = sql[3:]
        sql = sql.strip()
    return sql


def ask(question: str) -> pd.DataFrame:
    session = get_session()
    sql = nl_to_sql(question)
    print(f"Generated SQL:\n{sql}\n")
    return session.sql(sql).to_pandas()


if __name__ == "__main__":
    print(ask("Which 5 fire type Pokemon have the highest speed?"))
