"""Train a classifier to predict is_legendary from stats using Snowpark ML."""
from __future__ import annotations

from snowflake.ml.modeling.ensemble import RandomForestClassifier
from snowflake.ml.modeling.metrics import accuracy_score, f1_score
from snowflake.ml.registry import Registry
from snowflake.snowpark.functions import col, iff, lit

from src.config import get_session

FEATURES = ["HP", "ATTACK", "DEFENSE", "SP_ATTACK", "SP_DEFENSE", "SPEED",
            "BASE_TOTAL", "HEIGHT_M", "WEIGHT_KG", "GENERATION"]
LABEL = "IS_LEGENDARY_INT"
MODEL_NAME = "POKEMON_LEGENDARY_CLF"


def train() -> None:
    session = get_session()
    df = session.table("POKEDEX.MARTS.DIM_POKEMON").select(
        *[col(c) for c in FEATURES],
        iff(col("IS_LEGENDARY"), lit(1), lit(0)).alias(LABEL),
    )
    df = df.dropna()

    train_df, test_df = df.random_split([0.8, 0.2], seed=42)

    clf = RandomForestClassifier(
        input_cols=FEATURES,
        label_cols=[LABEL],
        output_cols=["PREDICTION"],
        n_estimators=200,
        class_weight="balanced",
        random_state=42,
    )
    clf.fit(train_df)

    preds = clf.predict(test_df)
    acc = accuracy_score(df=preds, y_true_col_names=LABEL, y_pred_col_names="PREDICTION")
    f1 = f1_score(df=preds, y_true_col_names=LABEL, y_pred_col_names="PREDICTION")
    print(f"Legendary classifier - accuracy={acc:.3f} f1={f1:.3f}")

    reg = Registry(session=session, database_name="POKEDEX", schema_name="ML")
    reg.log_model(
        clf,
        model_name=MODEL_NAME,
        version_name="V1",
        comment="Predicts is_legendary from Pokemon stats",
        metrics={"accuracy": acc, "f1": f1},
    )
    print(f"Registered model {MODEL_NAME}/V1")


if __name__ == "__main__":
    train()
