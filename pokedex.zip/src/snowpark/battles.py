"""Simulate battles between all Pokemon pairs using Snowpark."""
from __future__ import annotations

from snowflake.snowpark import functions as F

from src.config import get_session

# Sample pool size: all 800+ Pokemon means ~640k battles.
# Default to top-N by BASE_TOTAL for speed; set SAMPLE=None for full cross join.
SAMPLE = 200


def _attacker_score(df, suffix: str):
    """Battle score = attack * type-effectiveness vs opponent, modulated by speed and defense."""
    return (
        F.col(f"ATTACK_{suffix}") * F.col("MULTIPLIER")
        + F.col(f"SP_ATTACK_{suffix}") * F.col("MULTIPLIER") * F.lit(0.5)
        + F.col(f"SPEED_{suffix}") * F.lit(0.2)
    )


def build_battles() -> None:
    session = get_session()
    dim = session.table("POKEDEX.MARTS.DIM_POKEMON")
    fte = session.table("POKEDEX.MARTS.FACT_TYPE_EFFECTIVENESS")

    if SAMPLE is not None:
        dim = dim.order_by(F.col("BASE_TOTAL").desc()).limit(SAMPLE)

    a = dim.select(
        F.col("POKEDEX_NUMBER").alias("A_ID"),
        F.col("NAME").alias("A_NAME"),
        F.col("TYPE1").alias("A_TYPE1"),
        F.col("ATTACK").alias("ATTACK_A"),
        F.col("SP_ATTACK").alias("SP_ATTACK_A"),
        F.col("SPEED").alias("SPEED_A"),
        F.col("DEFENSE").alias("DEFENSE_A"),
        F.col("HP").alias("HP_A"),
    )
    b = dim.select(
        F.col("POKEDEX_NUMBER").alias("B_ID"),
        F.col("NAME").alias("B_NAME"),
        F.col("TYPE1").alias("B_TYPE1"),
        F.col("ATTACK").alias("ATTACK_B"),
        F.col("SP_ATTACK").alias("SP_ATTACK_B"),
        F.col("SPEED").alias("SPEED_B"),
        F.col("DEFENSE").alias("DEFENSE_B"),
        F.col("HP").alias("HP_B"),
    )

    pairs = a.cross_join(b).where(F.col("A_ID") != F.col("B_ID"))

    # Effectiveness of A's type vs B
    eff_ab = fte.select(
        F.col("POKEDEX_NUMBER").alias("B_ID2"),
        F.col("ATTACKING_TYPE").alias("A_TYPE_CHECK"),
        F.col("MULTIPLIER").alias("MULT_AB"),
    )
    # Effectiveness of B's type vs A
    eff_ba = fte.select(
        F.col("POKEDEX_NUMBER").alias("A_ID2"),
        F.col("ATTACKING_TYPE").alias("B_TYPE_CHECK"),
        F.col("MULTIPLIER").alias("MULT_BA"),
    )

    joined = (
        pairs.join(
            eff_ab,
            (pairs["B_ID"] == eff_ab["B_ID2"])
            & (pairs["A_TYPE1"] == eff_ab["A_TYPE_CHECK"]),
        )
        .join(
            eff_ba,
            (pairs["A_ID"] == eff_ba["A_ID2"])
            & (pairs["B_TYPE1"] == eff_ba["B_TYPE_CHECK"]),
        )
    )

    scored = joined.with_column(
        "A_SCORE",
        (F.col("ATTACK_A") + F.col("SP_ATTACK_A") * F.lit(0.5)) * F.col("MULT_AB")
        + F.col("SPEED_A") * F.lit(0.2)
        - F.col("DEFENSE_B") * F.lit(0.3),
    ).with_column(
        "B_SCORE",
        (F.col("ATTACK_B") + F.col("SP_ATTACK_B") * F.lit(0.5)) * F.col("MULT_BA")
        + F.col("SPEED_B") * F.lit(0.2)
        - F.col("DEFENSE_A") * F.lit(0.3),
    )

    result = scored.select(
        F.col("A_ID").alias("ATTACKER_ID"),
        F.col("B_ID").alias("DEFENDER_ID"),
        F.col("A_NAME").alias("ATTACKER_NAME"),
        F.col("B_NAME").alias("DEFENDER_NAME"),
        F.col("A_SCORE").alias("ATTACKER_SCORE"),
        F.col("B_SCORE").alias("DEFENDER_SCORE"),
        F.when(F.col("A_SCORE") >= F.col("B_SCORE"), F.col("A_ID"))
         .otherwise(F.col("B_ID")).alias("WINNER_ID"),
    )

    result.write.mode("overwrite").save_as_table("POKEDEX.MARTS.FACT_BATTLES")
    print(f"FACT_BATTLES: {result.count()} rows")

    # Aggregated win rates
    battles = session.table("POKEDEX.MARTS.FACT_BATTLES")
    wins = battles.group_by("ATTACKER_ID", "ATTACKER_NAME").agg(
        F.sum(F.when(F.col("WINNER_ID") == F.col("ATTACKER_ID"), 1).otherwise(0)).alias("WINS"),
        F.count("*").alias("TOTAL"),
    ).with_column("WIN_RATE", F.col("WINS") / F.col("TOTAL")).select(
        F.col("ATTACKER_ID").alias("POKEDEX_NUMBER"),
        F.col("ATTACKER_NAME").alias("NAME"),
        "WINS", "TOTAL", "WIN_RATE",
    )
    wins.write.mode("overwrite").save_as_table("POKEDEX.MARTS.AGG_WIN_RATES")
    print("AGG_WIN_RATES built.")


if __name__ == "__main__":
    build_battles()
