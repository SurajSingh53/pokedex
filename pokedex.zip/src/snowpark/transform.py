"""Build MARTS tables from RAW using Snowpark DataFrames."""
from __future__ import annotations

from snowflake.snowpark import functions as F

from src.config import get_session

TYPES = [
    "bug", "dark", "dragon", "electric", "fairy", "fight", "fire", "flying",
    "ghost", "grass", "ground", "ice", "normal", "poison", "psychic", "rock",
    "steel", "water",
]


def build_dim_pokemon() -> None:
    session = get_session()
    src = session.table("POKEDEX.RAW.POKEMON_STATS")

    dim = src.select(
        F.col("POKEDEX_NUMBER"),
        F.col("NAME"),
        F.lower(F.col("TYPE1")).alias("TYPE1"),
        F.lower(F.col("TYPE2")).alias("TYPE2"),
        F.col("GENERATION"),
        (F.col("IS_LEGENDARY") == 1).alias("IS_LEGENDARY"),
        F.col("HP"), F.col("ATTACK"), F.col("DEFENSE"),
        F.col("SP_ATTACK"), F.col("SP_DEFENSE"), F.col("SPEED"),
        F.col("BASE_TOTAL"), F.col("HEIGHT_M"), F.col("WEIGHT_KG"),
        F.col("CLASSFICATION"), F.col("ABILITIES"),
    )
    dim.write.mode("overwrite").save_as_table("POKEDEX.MARTS.DIM_POKEMON")
    print(f"DIM_POKEMON: {dim.count()} rows")


def build_dim_types() -> None:
    session = get_session()
    df = session.create_dataframe([(t,) for t in TYPES], schema=["TYPE_NAME"])
    df.write.mode("overwrite").save_as_table("POKEDEX.MARTS.DIM_TYPES")
    print(f"DIM_TYPES: {df.count()} rows")


def build_fact_type_effectiveness() -> None:
    session = get_session()
    src = session.table("POKEDEX.RAW.POKEMON_STATS")

    unions = []
    for t in TYPES:
        col_name = f"AGAINST_{t.upper()}"
        unions.append(
            src.select(
                F.col("POKEDEX_NUMBER"),
                F.col("NAME"),
                F.lit(t).alias("ATTACKING_TYPE"),
                F.col(col_name).alias("MULTIPLIER"),
            )
        )
    fact = unions[0]
    for u in unions[1:]:
        fact = fact.union_all(u)

    fact.write.mode("overwrite").save_as_table("POKEDEX.MARTS.FACT_TYPE_EFFECTIVENESS")
    print(f"FACT_TYPE_EFFECTIVENESS: {fact.count()} rows")


def run_all() -> None:
    build_dim_pokemon()
    build_dim_types()
    build_fact_type_effectiveness()


if __name__ == "__main__":
    run_all()
