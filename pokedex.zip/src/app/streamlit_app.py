"""Pokedex Intelligence Platform - Streamlit UI.

Run locally:
    streamlit run src/app/streamlit_app.py
"""
from __future__ import annotations

import pandas as pd
import plotly.express as px
import streamlit as st

from src.config import IMAGES_DIR, get_session
from src.ml import cortex_qa, embeddings

st.set_page_config(page_title="Pokedex Intelligence", page_icon="", layout="wide")


@st.cache_resource
def session():
    return get_session()


@st.cache_data(ttl=600)
def load_dim() -> pd.DataFrame:
    return session().table("POKEDEX.MARTS.DIM_POKEMON").to_pandas()


@st.cache_data(ttl=600)
def load_image_meta() -> pd.DataFrame:
    return session().table("POKEDEX.RAW.POKEMON_IMAGES").to_pandas()


def image_path(name: str) -> str | None:
    meta = load_image_meta()
    row = meta[meta["NAME"] == name]
    if row.empty:
        return None
    return str(IMAGES_DIR / row.iloc[0]["FILE_NAME"])


# Sidebar
st.sidebar.title("Pokedex Intelligence")
page = st.sidebar.radio(
    "Navigate",
    ["Explorer", "Compare", "Visually Similar", "Team Builder", "Insights", "Ask AI"],
)

dim = load_dim()

# -------------- Explorer --------------
if page == "Explorer":
    st.header("Pokemon Explorer")
    col1, col2, col3 = st.columns(3)
    types = sorted(set(dim["TYPE1"].dropna().unique()) | set(dim["TYPE2"].dropna().unique()) - {""})
    with col1:
        f_type = st.selectbox("Type", ["(any)"] + types)
    with col2:
        f_gen = st.selectbox("Generation", ["(any)"] + sorted(dim["GENERATION"].unique().tolist()))
    with col3:
        f_legendary = st.selectbox("Legendary", ["(any)", "Yes", "No"])

    view = dim.copy()
    if f_type != "(any)":
        view = view[(view["TYPE1"] == f_type) | (view["TYPE2"] == f_type)]
    if f_gen != "(any)":
        view = view[view["GENERATION"] == f_gen]
    if f_legendary != "(any)":
        view = view[view["IS_LEGENDARY"] == (f_legendary == "Yes")]

    st.caption(f"{len(view)} Pokemon matched")
    st.dataframe(view, use_container_width=True, height=500)

    name = st.selectbox("Select a Pokemon for details", view["NAME"].tolist())
    if name:
        row = view[view["NAME"] == name].iloc[0]
        c1, c2 = st.columns([1, 2])
        p = image_path(name)
        if p:
            c1.image(p, width=250)
        c2.subheader(name)
        c2.write(f"**Type:** {row['TYPE1']} / {row['TYPE2'] or '-'}")
        c2.write(f"**Generation:** {row['GENERATION']} | **Legendary:** {row['IS_LEGENDARY']}")
        stats = row[["HP", "ATTACK", "DEFENSE", "SP_ATTACK", "SP_DEFENSE", "SPEED"]].to_frame("value")
        c2.bar_chart(stats)

# -------------- Compare --------------
elif page == "Compare":
    st.header("Compare Two Pokemon")
    c1, c2 = st.columns(2)
    names = sorted(dim["NAME"].tolist())
    a = c1.selectbox("Pokemon A", names, index=names.index("Charizard") if "Charizard" in names else 0)
    b = c2.selectbox("Pokemon B", names, index=names.index("Blastoise") if "Blastoise" in names else 1)

    ra = dim[dim["NAME"] == a].iloc[0]
    rb = dim[dim["NAME"] == b].iloc[0]

    pa = image_path(a); pb = image_path(b)
    if pa: c1.image(pa, width=220)
    if pb: c2.image(pb, width=220)

    stat_cols = ["HP", "ATTACK", "DEFENSE", "SP_ATTACK", "SP_DEFENSE", "SPEED"]
    chart_df = pd.DataFrame({
        "stat": stat_cols,
        a: [ra[s] for s in stat_cols],
        b: [rb[s] for s in stat_cols],
    })
    fig = px.line_polar(
        chart_df.melt(id_vars="stat", var_name="pokemon", value_name="value"),
        r="value", theta="stat", color="pokemon", line_close=True,
    )
    st.plotly_chart(fig, use_container_width=True)

    # Quick battle score
    winner = a if ra["BASE_TOTAL"] >= rb["BASE_TOTAL"] else b
    st.success(f"Likely winner by base total: **{winner}**")

# -------------- Visually Similar --------------
elif page == "Visually Similar":
    st.header("Visually Similar Pokemon (Vector Search)")
    names = sorted(dim["NAME"].tolist())
    name = st.selectbox("Pick a Pokemon", names)
    k = st.slider("Top K", 3, 20, 10)
    if st.button("Find similar"):
        pdex = int(dim[dim["NAME"] == name].iloc[0]["POKEDEX_NUMBER"])
        try:
            sim = embeddings.find_similar(pdex, top_k=k)
            st.dataframe(sim, use_container_width=True)
            cols = st.columns(min(5, len(sim)))
            for i, r in sim.iterrows():
                p = image_path(r["NAME"])
                if p:
                    cols[i % len(cols)].image(p, caption=r["NAME"], width=120)
        except Exception as e:
            st.error(f"Vector search failed. Did you run embeddings upload? {e}")

# -------------- Team Builder --------------
elif page == "Team Builder":
    st.header("Team Builder & Weakness Analysis")
    names = sorted(dim["NAME"].tolist())
    team = st.multiselect("Pick up to 6 Pokemon", names, max_selections=6)
    if team:
        sess = session()
        ids = dim[dim["NAME"].isin(team)]["POKEDEX_NUMBER"].tolist()
        id_list = ",".join(str(i) for i in ids)
        fte = sess.sql(
            f"""SELECT ATTACKING_TYPE, SUM(MULTIPLIER) AS TOTAL_WEAKNESS
                FROM POKEDEX.MARTS.FACT_TYPE_EFFECTIVENESS
                WHERE POKEDEX_NUMBER IN ({id_list})
                GROUP BY ATTACKING_TYPE ORDER BY TOTAL_WEAKNESS DESC"""
        ).to_pandas()
        st.bar_chart(fte.set_index("ATTACKING_TYPE"))
        worst = fte.head(3)["ATTACKING_TYPE"].tolist()
        st.warning(f"Your team is weakest against: {', '.join(worst)}")

# -------------- Insights --------------
elif page == "Insights":
    st.header("Dataset Insights")
    c1, c2 = st.columns(2)
    type_counts = dim["TYPE1"].value_counts().reset_index()
    type_counts.columns = ["type", "count"]
    c1.plotly_chart(px.bar(type_counts, x="type", y="count", title="Primary Type Distribution"),
                    use_container_width=True)
    gen_legend = dim.groupby(["GENERATION", "IS_LEGENDARY"]).size().reset_index(name="count")
    c2.plotly_chart(
        px.bar(gen_legend, x="GENERATION", y="count", color="IS_LEGENDARY",
               title="Legendary vs Non-Legendary by Generation"),
        use_container_width=True,
    )
    st.plotly_chart(
        px.scatter(dim, x="ATTACK", y="DEFENSE", color="TYPE1",
                   hover_data=["NAME"], title="Attack vs Defense"),
        use_container_width=True,
    )

# -------------- Ask AI --------------
elif page == "Ask AI":
    st.header("Ask AI (Snowflake Cortex)")
    q = st.text_input("Ask a question about Pokemon",
                      "Which 5 fire type Pokemon have the highest speed?")
    if st.button("Ask") and q:
        with st.spinner("Thinking..."):
            try:
                sql = cortex_qa.nl_to_sql(q)
                st.code(sql, language="sql")
                result = session().sql(sql).to_pandas()
                st.dataframe(result, use_container_width=True)
            except Exception as e:
                st.error(f"Cortex query failed: {e}")
