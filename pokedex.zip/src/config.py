"""Snowflake session + project paths."""
from __future__ import annotations

import os
from functools import lru_cache
from pathlib import Path

from dotenv import load_dotenv
from snowflake.snowpark import Session

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = PROJECT_ROOT / "Data"
IMAGES_DIR = DATA_DIR / "Images"
STATS_CSV = DATA_DIR / "pokemon (1).csv"
EVOLUTION_CSV = DATA_DIR / "pokemon.csv"
SQL_DIR = PROJECT_ROOT / "sql"

load_dotenv(PROJECT_ROOT / ".env")


def _connection_params() -> dict:
    required = [
        "SNOWFLAKE_ACCOUNT",
        "SNOWFLAKE_USER",
        "SNOWFLAKE_PASSWORD",
    ]
    missing = [k for k in required if not os.getenv(k)]
    if missing:
        raise RuntimeError(
            f"Missing Snowflake env vars: {missing}. Copy .env.example to .env and fill it in."
        )
    return {
        "account": os.environ["SNOWFLAKE_ACCOUNT"],
        "user": os.environ["SNOWFLAKE_USER"],
        "password": os.environ["SNOWFLAKE_PASSWORD"],
        "role": os.getenv("SNOWFLAKE_ROLE", "POKE_ROLE"),
        "warehouse": os.getenv("SNOWFLAKE_WAREHOUSE", "POKE_WH"),
        "database": os.getenv("SNOWFLAKE_DATABASE", "POKEDEX"),
        "schema": os.getenv("SNOWFLAKE_SCHEMA", "RAW"),
    }


@lru_cache(maxsize=1)
def get_session() -> Session:
    """Return a cached Snowpark session."""
    return Session.builder.configs(_connection_params()).create()


def close_session() -> None:
    get_session.cache_clear()
