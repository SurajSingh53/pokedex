"""Load the two CSVs into RAW.POKEMON_STATS and RAW.POKEMON_EVOLUTION."""
from __future__ import annotations

import pandas as pd

from src.config import EVOLUTION_CSV, STATS_CSV, get_session


def _clean_stats(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df.columns = [c.upper() for c in df.columns]
    # Normalize numeric columns that may have blanks
    for col in ["PERCENTAGE_MALE", "HEIGHT_M", "WEIGHT_KG"]:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    df["TYPE2"] = df["TYPE2"].fillna("")
    return df


def _clean_evolution(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df.columns = [c.upper() for c in df.columns]
    df["EVOLUTION"] = df["EVOLUTION"].fillna("")
    df["TYPE2"] = df["TYPE2"].fillna("")
    return df


def load() -> None:
    session = get_session()

    stats = _clean_stats(pd.read_csv(STATS_CSV))
    print(f"Loading {len(stats)} rows -> RAW.POKEMON_STATS")
    session.write_pandas(
        stats,
        table_name="POKEMON_STATS",
        database="POKEDEX",
        schema="RAW",
        overwrite=True,
        auto_create_table=False,
    )

    evo = _clean_evolution(pd.read_csv(EVOLUTION_CSV))
    print(f"Loading {len(evo)} rows -> RAW.POKEMON_EVOLUTION")
    session.write_pandas(
        evo,
        table_name="POKEMON_EVOLUTION",
        database="POKEDEX",
        schema="RAW",
        overwrite=True,
        auto_create_table=False,
    )

    print("CSV load complete.")


if __name__ == "__main__":
    load()
