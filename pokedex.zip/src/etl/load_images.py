"""Upload Pokemon images to the Snowflake stage and register metadata."""
from __future__ import annotations

import re

import pandas as pd

from src.config import IMAGES_DIR, get_session

STAGE = "@POKEDEX.RAW.POKE_IMAGES_STAGE"


def _normalize(name: str) -> str:
    """Normalize a Pokemon name to match image filenames (lowercase, no special chars)."""
    name = name.lower().strip()
    name = re.sub(r"[^a-z0-9\-]", "", name.replace(" ", "-"))
    return name


def _match_image(name: str) -> str | None:
    """Find the image file for a given Pokemon name (handles forms like 'deoxys-normal')."""
    candidate = IMAGES_DIR / f"{_normalize(name)}.png"
    if candidate.exists():
        return candidate.name
    # Try prefix match (e.g. deoxys -> deoxys-normal.png)
    prefix = _normalize(name)
    matches = sorted(IMAGES_DIR.glob(f"{prefix}-*.png"))
    if matches:
        return matches[0].name
    return None


def load() -> None:
    session = get_session()

    stats = session.table("POKEDEX.RAW.POKEMON_STATS").select("POKEDEX_NUMBER", "NAME").to_pandas()

    rows = []
    missing = []
    for _, row in stats.iterrows():
        pdex = int(row["POKEDEX_NUMBER"])
        name = row["NAME"]
        fname = _match_image(name)
        if fname is None:
            missing.append(name)
            continue
        rows.append(
            {
                "POKEDEX_NUMBER": pdex,
                "NAME": name,
                "FILE_NAME": fname,
                "STAGE_PATH": f"{STAGE}/{fname}",
            }
        )

    print(f"Matched {len(rows)} images. Missing: {len(missing)} -> e.g. {missing[:5]}")

    # PUT images onto the stage (auto_compress disabled to keep png intact)
    print("Uploading images to stage (this may take a few minutes)...")
    put_sql = (
        f"PUT 'file://{IMAGES_DIR.as_posix()}/*.png' {STAGE} "
        "AUTO_COMPRESS=FALSE OVERWRITE=TRUE"
    )
    session.sql(put_sql).collect()

    meta = pd.DataFrame(rows)
    session.write_pandas(
        meta,
        table_name="POKEMON_IMAGES",
        database="POKEDEX",
        schema="RAW",
        overwrite=True,
        auto_create_table=False,
    )
    print(f"Registered {len(meta)} image metadata rows.")


if __name__ == "__main__":
    load()
