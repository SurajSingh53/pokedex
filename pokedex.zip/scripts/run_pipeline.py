"""Run the full pipeline end-to-end: DDL -> ETL -> Transform -> Battles -> Embeddings -> ML."""
from __future__ import annotations

from scripts import run_ddl
from src.etl import load_csv, load_images
from src.ml import embeddings, train_legendary, train_type
from src.snowpark import battles, transform


def main() -> None:
    print("== 1. DDL ==")
    run_ddl.main()

    print("\n== 2. Load CSVs ==")
    load_csv.load()

    print("\n== 3. Upload images ==")
    load_images.load()

    print("\n== 4. Snowpark transforms ==")
    transform.run_all()

    print("\n== 5. Battle simulation ==")
    battles.build_battles()

    print("\n== 6. Image embeddings ==")
    df = embeddings.compute_embeddings()
    embeddings.upload(df)

    print("\n== 7. Train legendary classifier ==")
    train_legendary.train()

    print("\n== 8. Train type classifier ==")
    train_type.train()

    print("\nPipeline complete. Launch UI with:  streamlit run src/app/streamlit_app.py")


if __name__ == "__main__":
    main()
