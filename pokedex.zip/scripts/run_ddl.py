"""Execute sql/ddl.sql against Snowflake."""
from __future__ import annotations

from src.config import SQL_DIR, get_session


def main() -> None:
    session = get_session()
    sql_text = (SQL_DIR / "ddl.sql").read_text(encoding="utf-8")

    statements = [s.strip() for s in sql_text.split(";") if s.strip() and not s.strip().startswith("--")]
    for stmt in statements:
        print(f"Executing: {stmt.splitlines()[0][:80]}...")
        session.sql(stmt).collect()

    print(f"Done. Ran {len(statements)} statements.")


if __name__ == "__main__":
    main()
